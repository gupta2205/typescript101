import React from 'react';
import './App.css';
import './tachyons.css';

const App: React.FC = () => {

  return (
      <div className={"App"} >
        <div className={"App-header bg-blue"}> 
          CXO Web Glass Learning Demo!!! 
        </div>
      </div>  
   );
};

export default App;
